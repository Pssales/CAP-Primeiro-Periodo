class No
{
    public:
        int value_;
        No *previous_;
        No *next_;
};